// Doney Tran
// 3/13/23
// CS 163 Hybrid
// Program 5

#include "table.h"
int main()
{
	graph recipeGraph;	
	string recipe;
	string vertex, attach;
	int choice;

	//MENU
	do
	{	
		cout << "\tMENU" << endl;
		cout << "=====================" << endl;
		cout << "1. Add a Recipe/Step" << endl;
		cout << "2. Link up Recipe/Step" << endl;
		cout << "3. Display Recipe/Step" << endl;
		cout << "4. Find Recipe/Step " << endl;
		cout << "5. Exit Program" << endl;
		cout << endl;
		cout << "Please read and select the number from the list: ";
		cin >> choice;
		cin.ignore(100, '\n');

		switch (choice)
		{
			case 1:
				try
				{
					cout << "Please enter in the recipe/step (ex. heat pan to medium high): ";
					getline(cin, recipe);

					recipeGraph.insertVertex(recipe);

					cout << endl << "Successfully added the recipe/step" << endl;
					
				}

				catch (const char * error)
				{
					cerr << error << endl;
				}

				break;

			case 2:

				try
				{
					cout << "Please enter the Recipe/Step: ";
				     	getline(cin, vertex);

					cout << "Next enter the other Recipe/Step to create a link between the two: ";
					getline(cin, attach);

					recipeGraph.insertEdge(vertex, attach);
					cout << "You have linked " << vertex << " ----> " << attach << endl;
						
				}

				catch (const char * error)
				{
					cerr << error << endl;
				}
				break;

			case 3:

				try
				{
					recipeGraph.displayVertex();
				}

				catch (const char * error)
				{
					cerr << error << endl;
				}
				break;

			case 4:

				try
				{
					string find;
					cout << "Enter the recipe/step to search: ";
					getline(cin, find);

					int location = recipeGraph.findLocation(find);
					// Debugging
					//cout << "location of step: " << location << endl;
				}

				catch (const char * error)
				{
					cerr << error << endl;
				}
				break;
			
			case 5:
				cout << "Exiting the program. Thank you and have a great day!" << endl;
				break;

			default:
				cout << "Invalid input, please try agian." << endl << endl;






		}


	} while (choice != 5); 








	return 0;
}
