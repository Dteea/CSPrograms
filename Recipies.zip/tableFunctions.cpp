// Doney Tran
// 3/13/23
// CS 163 Hybrid
// Program 5

// This file has the implementations of a graph and can be used to 
// create different variations of relationships. In this case, the client
// is able to create and interact with graphs that deal with recipies. The main
// functions this graph can do are adding in points of interest, linking them up, and
// displaying them.

#include "table.h"

// Default constructor
graph::graph()
{

	listSize = 10;

	adjacencyList = new vertex[listSize];

	for (int i = 0; i < listSize; ++i)
	{
		adjacencyList[i].head = nullptr;
	}


}

// Let the client choose how many vertices they want
graph::graph(int size)
{

	listSize = size;

	adjacencyList = new vertex[listSize];

	for (int i = 0; i < listSize; ++i)
	{
		adjacencyList[i].head = nullptr;
	}


}

// Default destructor
graph::~graph()
{

	for (int i = 0; i < listSize; ++i)
	{
			destroyEdge(adjacencyList[i].head);	
	}

	delete [] adjacencyList;
	adjacencyList = nullptr;
}

// This function takes in a string from the client to copy it into
// a string object for a vertex. It will throw a message if the string
// could not be added or return a 1 if successful
int graph::insertVertex(string & recipe)
{
	if (recipe.empty()) throw "There is no recipe to be inserted";

	int i = 0;

	while (i < listSize && !adjacencyList[i].recipeStep.empty())
	{
		++i;
	}

	adjacencyList[i].recipeStep = recipe;
	return 1;
}

// This function takes in a string from the client or one of the member function's argument
// to find the index position of the string they are looking for. It will throw an error message
// if the string passed in is empty, throw an error message if there was no match,
// or return the index position value
int graph::findLocation(string & key)
{
	if (key.empty()) throw "Location function did not receive a filled string object";

	int i = 0;
	int location = -11;
	int success = 0;
	while (i < listSize && !adjacencyList[i].recipeStep.empty())
	{
		
		if (adjacencyList[i].recipeStep == key)
		{
			location = i;
		}

		++i;
	}

	if (location == -11)
	{
		throw "Location could not be found";
	}

	return location;

}

// This function works with the findLocation helper member function to locate
// a pair of vertices to create a connection/relationship between them. It takes in
// 2 string objects. It will throw an error message if either string objects were empty, otherwise
// it will return a 1 if successful
int graph::insertEdge(string & currentVertex, string & linkUp)
{
	if (currentVertex.empty() || linkUp.empty()) throw "Could not establish a link between the two";

	int currentLocation = 0;
	int attach = 0;

	currentLocation = findLocation(currentVertex);
	attach = findLocation(linkUp);

	if (!adjacencyList[currentLocation].head)
	{
		adjacencyList[currentLocation].head = new edge;
		adjacencyList[currentLocation].head->adjacent = &adjacencyList[attach];

		adjacencyList[currentLocation].head->next = nullptr;;
	}
			
	else
	{
		insertEdge(adjacencyList[currentLocation].head, attach);
	}

	return 1;
}

// This function will display all vertices and what it's relationships are to other vertices.
// It will throw an error message if there is no adjacency list created, other wise the function
// will return a 1 if successful
int graph::displayVertex()
{

	if (!adjacencyList) throw "There is nothing to display";

	cout << "Recipe/steps in the order added" << endl;

	for (int i = 0; i < listSize; ++i)
	{
		if (!adjacencyList[i].recipeStep.empty())
		{
			edge * current = adjacencyList[i].head;
			//cout << "Position # " << i << endl;	
			cout << "RECIPE/STEP" << endl;
			cout << "===========" << endl;
			cout << adjacencyList[i].recipeStep << endl << endl;;
			cout << "Next steps:" << endl;	

			while (current)
			{
				cout << current->adjacent->recipeStep << endl;
				current = current->next;
			}
		}
	}


	return 1;
}

// Recursive functions

// This function takes in the starting point of the edge list of a vertex which is called the "head".
// It will traverse through the list and when it reaches the end (nullptr), it will create
// a new edge and store the location of the vertex from the attach argument passed in. It will
// return a 1 if successful
int graph::insertEdge(edge * &head, int attach) 
{
	if (!head)
	{
		head = new edge;
		head->adjacent = &adjacencyList[attach];
		head->next = nullptr;
		return 1;
	}

	return insertEdge(head->next, attach);
}

// This function takes in the starting point of the edge list of a vertex. Using head recursion
// it will traverse through and on it's way back, it will deallocate the edges. It will return
// a 1 if successful
int graph::destroyEdge(edge *& head)
{
	if (!head) return 0;

	destroyEdge(head->next);

	head->adjacent = nullptr;	
	head->next = nullptr;
	delete head;
	return 1;
}
