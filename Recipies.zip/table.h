// Doney Tran
// 3/13/23
// CS 163 Hybrid
// Program 5


// This file contains a layout for a graph that will be dealing
// with recipe relationships. For example if the client wanted to make
// pancakes, they could store a varying amount of steps and connect them
// all together. Maybe to start off, the client can mix in dry ingredients
// or they can do something else and then connect those step to that mixing
// step.

#include <cstring>
#include <cctype>
#include <string>
#include <iostream>
using namespace std;

struct vertex
{
	string recipeStep;
	struct edge * head;

};

struct edge
{
	vertex * adjacent;
	edge * next;

};

class graph
{

	public:
		graph();
		graph(int size);
		~graph();
	
		int insertVertex(string & recipe);
		int findLocation(string & key);
		int insertEdge(string & currentVertex, string & linkUp);
		int displayVertex();
	private:

		vertex * adjacencyList;
		int listSize;

		int insertEdge(edge * &head, int attach);
		int destroyEdge(edge * &head);
};
