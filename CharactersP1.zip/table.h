// Doney Tran
// CS 163 Hybrd
// 2/13/23
// Program 3

// This file contains the functions for a table ADT.
// It will have a pretty good hash function (I hope) to
// insert and retrieve superheros/characters from the hash table 

#include "character.h"
#include <fstream>
// CONSTANTS
const int SIZE = {201}; 
const int SIZE2 {601};
// A node that will contain the character class object
struct node
{
	characterBase character;
	node * next;
};

class table
{

	public:
		table(); // default constructor with size of 201
		table(int size); // Client can choose size
		~table();

		int insert(char characterName[], characterBase & addCharacter);
		int retrieve(char characterName[], characterBase characterMatch[]);
		int displayCharacterMatch(char characterName[]);
		int displayAbilityMatch(char ability[]);
		int removeCharacter(char characterName[]);


		int displayTable();
		int loadFile(char fileName[], characterBase & fillCharacter);	
	private:
		node ** hashTable;
		int hashTableSize;

		int hashFunction(char characterName[]);
		int destroyTableRecursively(node * &head);
		int removeMatchRecursively(node * &head, char name[]);
};









