// Doney Tran
// CS 163 Hybrd
// 2/13/23
// Program 3


// This file contains the member function implemtations of the table ADT. The client will be able to
// create a specific size of table of their choosing and have the ability to test out
// a decent hash function. The client is able to load an external data file formatted in the way:
// name|abilites/power|species|description \n (newline, or enter)
// into the hash table for storage and interactions

//struct node
//{
//	characterBase character;
//	node * next;
//};

//node ** hashTable;
//int hashTableSize;

#include "table.h"
// default constructor with a hash table size of 201
table::table()
{
	hashTable = nullptr;
	hashTableSize = SIZE;
	hashTable = new node * [SIZE];
	
	for (int i = 0; i < SIZE; ++i)
	{
		hashTable[i] = nullptr;
	}


}

// Client specified hash table size constructor
table::table(int size)
{

	hashTable = nullptr;
	hashTableSize = size;
	hashTable = new node * [size];

	for (int i = 0; i < size; ++i)
	{
		hashTable[i] = nullptr;
	}


}

// destructor
table::~table()
{
	
	if (hashTable)
	{
		for (int i = 0; i < hashTableSize; ++i)
		{

			if (hashTable[i])
			{
				destroyTableRecursively(hashTable[i]);
			}

		}

		delete [] hashTable;
	}

}

// This function will take in a character's name and a characterBase object to add
// to the hash table. It will throw 0 if a null name was passed in or return a 1
// if successful
int table::insert(char characterName[], characterBase & addCharacter)
{
	if (!characterName) throw 0;
	int index = hashFunction(characterName);

	if (index > hashTableSize) throw 0;


	if (!hashTable[index])
	{
		hashTable[index] = new node;
		hashTable[index]->next = nullptr;
		hashTable[index]->character.addWholeCharacter(addCharacter);
	}

	else
	{
		node * temp = new node;
		temp->next = hashTable[index];
		temp->character.addWholeCharacter(addCharacter);		
		hashTable[index] = temp;	
	}	

	return 1;
}

// This function will take in a character's name and an empty characterBase object array.
// If the name is null, the function will throw a 0 or if a match wasn't found, it will return 0. 
// Otherwise the function will return how many characters it retrieved along with a the array of characters that has been filled with matches
int table::retrieve(char characterName[], characterBase characterMatch[])
{
	if (!characterName) throw 0;

	int success {0};	
	int index = hashFunction(characterName);
	int i = 0;
	if (hashTable[index])
	{
		node * current = hashTable[index];
		success = hashTable[index]->character.nameMatch(characterName);
		
		while (current)
		{
			success = current->character.nameMatch(characterName);	
			if (success)
			{
				characterMatch[i].addWholeCharacter(current->character);
				++i;
			}
			
			current = current->next;
		}

		

	}
	
	//for (int i = 0; i < hashTableSize; ++i)
	//{
	//	if (hashTable[i])
	//	{
	//		node * current = hashTable[i];	
	//		while (current)
	//		{

	//			success = current->character.nameMatch(characterName);
	//			if (success)
	//			{
	//				characterMatch.addWholeCharacter(current->character);
	//			}

	//			current = current->next;
	//		}
	//	}
	//}


	return i;
}

// This function will see if there is a match with the character name
// passed in as the argument. It will throw a 0 if a hashTable doesn't exist, return a 0 if a match was not found,
// or the function will display the match and return a 1 
int table::displayCharacterMatch(char characterName[])
{

	if (!hashTable) throw 0;
	int success {0};	
	int index {0};
	using namespace std;

	index = hashFunction(characterName);

	if (hashTable[index])
	{
		success = hashTable[index]->character.nameMatch(characterName);

		if (success)
		{
			cout << "Position: " << index << endl;
			hashTable[index]->character.displayCharacter();
		}

	}

	else
	{
		return 0;
	}
	//for (int i = 0; i < hashTableSize; ++i)
	//{
	//	if (hashTable[i])
	//	{
	//		node * current = hashTable[i];	
	//		while (current)
	//		{

	//			success = current->character.nameMatch(characterName);
	//			if (success)
	//			{
	//				cout << "Position: " << i << endl;
	//				current->character.displayCharacter();
	//			}
	//			
	//			current = current->next;
	//		}
	//	}
	//}


	return 1;	
}

// This function takes in a character name and use it to create a unique index for the hash table
// It will throw a 0 if the name is null or return the index for the hash table
int table::hashFunction(char key[])
{
	
	if (!key) throw 0;

	int index {0};
	int keyScramble {0};

	// Hash Function V1
//	for (int i = 0; i < int(strlen(key)); ++i)
//	{
//		index += int(key[i]);
//
//	}
//	index *= index;
//	index *= 11;
//
	//Hash Function V2
	for (int i = 0; i < int(strlen(key)); ++i)
	{
		keyScramble = int(key[i]);
		if (keyScramble % 2 == 0)
		{
			++keyScramble;
			keyScramble *= keyScramble;
			keyScramble *= keyScramble;
		}

		index += keyScramble;
	}

	// Bad Hash Function
	//index = int(key[0]);
		
	return index % hashTableSize;

}

// This function will display everything that is in the hash table. It will throw a 0
// if a hash table doesn't exist or return a 1 if it successfully displayed
int table::displayTable()
{
	if (!hashTable) throw 0;
	
	using namespace std;

	for (int i = 0; i < hashTableSize; ++i)
	{
		if (hashTable[i])
		{
			
			int positionTotal {0};

			cout << "Position: " << i << endl;
			node * current = hashTable[i];	
			while (current)
			{
				++positionTotal;
				current->character.displayCharacter();
				current = current->next;
			}
			
			// Look at spread of hash function	
			//cout << "Total Characters: " << positionTotal << endl << endl;
		}
	}

	return 1;
}

// This function will recursively traverse through the hash table, deleting the chains
// It will return a 1 if successful
int table::destroyTableRecursively(node * &head)
{
	if (!head) return 0;

	destroyTableRecursively(head->next);
	delete head;
	return 1;
}

// This function will take a file name and an empty characterBase object to
// load in an external data file into the hash table. It will throw a 0
// if the file name is null or if it could not find the exact match. Otherwise
// the function will return a 1 if successful
int table::loadFile(char fileName[], characterBase & fillCharacter)
{

	if (!fileName) throw 0;

	using namespace std;
	ifstream moveIn;

	char name[SIZE2];	
	char ability[SIZE2];	
	char species[SIZE2];	
	char description[SIZE2];	
	int count {0};

	moveIn.open(fileName);
	
	if (moveIn)
	{
		
		moveIn.get(name, SIZE2, '|');
		moveIn.ignore(SIZE2, '|');

		while (moveIn && !moveIn.eof())
		{

			moveIn.get(ability, SIZE2, '|');
			moveIn.ignore(SIZE2, '|');

			moveIn.get(species, SIZE2, '|');
			moveIn.ignore(SIZE2, '|');

			moveIn.get(description, SIZE2, '\n');
			moveIn.ignore(SIZE2, '\n');

			fillCharacter.addCharacter(name, ability, species, description);
			insert(name, fillCharacter);

			++count;
			// Check if next thing can be read	
			moveIn.get(name, SIZE2, '|');
			moveIn.ignore(SIZE2, '|');
		}

		moveIn.close();

	}

	else
	{
		throw 0;
	}

	return count;
}

// This function will take in a character name and search for a matching 
// name in the hash table and remove it from the table. It will throw a 0
// if either the name is null or a hash table doesn't exist
int table::removeCharacter(char characterName[])
{
	if (!characterName || !hashTable) throw 0;

	int success {0};
	int index = hashFunction(characterName);

	if (hashTable[index])
	{
		removeMatchRecursively(hashTable[index], characterName);
	}

	return 1;
}

// This function will take in a character ability to find an exact match. If the function
// finds a match, it will display the character and return a 1, otherwise the function will throw
// a 0 if the ability name passed in is null
int table::displayAbilityMatch(char ability[])
{
	if (!ability) throw 0;

	using namespace std;
	int success {0};	
	for (int i = 0; i < hashTableSize; ++i)
	{
		if (hashTable[i])
		{

			node * current = hashTable[i];	
			while (current)
			{
				success = current->character.abilityMatch(ability);
				if (success)
				{
					cout << "Position: " << i << endl;
					current->character.displayCharacter();
				}
				current = current->next;
			}
		}
	}





	return 1;
}

// This function will traverse recursively through the chain of the hash table
// to remove a character that matches the name passed in it will return a 1 if
// successful
int table::removeMatchRecursively(node *& head, char name[])
{
	if (!head) return 0;

	if (head->character.nameMatch(name) == 1)
	{
		node * temp = head->next;
		delete head;
		head = temp;	
		return 1;
	}

	return removeMatchRecursively(head->next, name);

}
