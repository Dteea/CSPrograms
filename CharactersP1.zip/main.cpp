// Doney Tran
// CS 163 Hybrid
// 2/13/23
// Program 3

#include "table.h"
using namespace std;


//const char FILENAME[] {"characters.txt"}; // Doney's original file with his characters
int main()
{

	// VARIABLES
	characterBase person;
	characterBase empty[10];
	characterBase empty2;
	table newTable(1001);

	char name[SIZE2];
	char ability[SIZE2];
	char species[SIZE2];
	char description[SIZE2];
	char fileName[SIZE2];
	char fileName2[SIZE2] = "characters.txt"; // Opens doney's original file
	char name2[SIZE];	
	int count {0};
	int choice {0};
	int retrieveTotal {0};

	// MENU
	do
	{
		cout << "===========" << endl;
		cout << "CHARACTER MENU" << endl;	
		cout << "===========" << endl;
		cout << "1. Add Character" << endl;
		cout << "2. Add a Whole Character" << endl;
		cout << "3. Display Character" << endl;
		cout << "4. Remove Character" << endl;
		cout << endl;	
		cout << "===========" << endl;
		cout << "TABLE MENU" << endl;	
		cout << "===========" << endl;
		cout << "5. Insert Character Into Table" << endl;
		cout << "6. Retrieve Character From Table" << endl;
		cout << "7. Find Matching Character Name" << endl;
		cout << "8. Find Matching Character Ability" << endl;
		cout << "9. Remove Character from Table" << endl;
		cout << "10. Display Table" << endl;
		cout << "11. Load External Data File" << endl;
		cout << "12. Exit Program" << endl;
		cout << endl;

		cout << "Please select an option from the table: ";
		cin >> choice;
		cin.ignore(SIZE, '\n');

		switch (choice)
		{
			case 1:

				cout << "Please enter in a name: ";
				cin.get(name, SIZE2, '\n');
				cin.ignore(SIZE, '\n');

				cout << "Please enter in the ability of the character: ";
				cin.get(ability, SIZE2, '\n');
				cin.ignore(SIZE, '\n');

				cout << "Please enter the species of the character: ";
				cin.get(species, SIZE2, '\n');
				cin.ignore(SIZE, '\n');

				cout << "Please enter the description/bio of the character: ";
				cin.get(description, SIZE2, '\n');
				cin.ignore(SIZE, '\n');


				try
				{
					person.addCharacter(name, ability, species, description);
					cout << endl << "Filled in the character" << endl;
				}

				catch (int)
				{
					cerr << "Could not add a character" << endl;
				}
				break;

			case 2:
				try
				{
					person.addWholeCharacter(person);
					cout << endl << "Filled the character with a whole character" << endl;
				}

				catch (int)
				{
					cerr << "Could not add a whole character" << endl;
				}
				break;

			case 3:
				try
				{
					person.displayCharacter();
				}

				catch (int)
				{
					cerr << "Cound not display the character" << endl;
				}
				break;

			case 4:
				try
				{
					person.removeCharacter();
					cout << "Cleared out the character" << endl;
				}

				catch (int)
				{
					cerr << "Could not clear out the character" << endl;
				}
				break;

			case 5:

				try
				{
					newTable.insert(name, person);
					cout << "The character has been added to the table" << endl;

				}

				catch (int)
				{
					cerr << "Could not add the character to the table" << endl;
				}
				break;

			case 6:

				cout << "Please enter in a name to search for: ";
				cin.get(name2, SIZE2, '\n');
				cin.ignore(SIZE, '\n');

				try
				{
					retrieveTotal = newTable.retrieve(name2, empty);
					
				}

				catch (int)
				{
					cerr << "We could not find a match" << endl;
				}
				cout << endl << "This is what was in the table" << endl;
				for (int i = 0; i < retrieveTotal; ++i)
				{
					empty[i].displayCharacter();
				}	
				break;

			case 7:

				cout << "Please enter in a name to search for: ";
				cin.get(name2, SIZE2, '\n');
				cin.ignore(SIZE, '\n');
				try
				{
					newTable.displayCharacterMatch(name2);
				}

				catch (int)
				{
					cerr << "Could not find the character in the table" << endl;
				}
				break;

			case 8:

				cout << "Please enter in a ability to search for: ";
				cin.get(name2, SIZE2, '\n');
				cin.ignore(SIZE, '\n');
				try
				{
					newTable.displayAbilityMatch(name2);
				}

				catch (int)
				{
					cerr << "Could not find the character(s) that matched that ability" << endl;
				}
				break;

			case 9:

				cout << "Please enter in a name to remove from the table: ";
				cin.get(name2, SIZE2, '\n');
				cin.ignore(SIZE, '\n');
				try
				{
					newTable.removeCharacter(name2);
					cout << name2 << " has been removed from the table" << endl;
				}

				catch (int)
				{
					cerr << "Could not remove that character from the table" << endl;
				}
				break;

			case 10:
				try
				{
					newTable.displayTable();
				}

				catch (int)
				{
					cerr << "Could not display table" << endl;
				}
				break;

			case 11:

				cout << "Please enter the file name to load: ";
				cin.get(fileName, SIZE2, '\n');
				cin.ignore(SIZE, '\n');
				try
				{
					count = newTable.loadFile(fileName, empty2);
					cout << count << " CHARACTERS LOADED IN" << endl;
				}

				catch (int)
				{
					cerr << "File does not exist, try to type in exactly what the file name is" << endl;
				}
				break;

			case 12:
				cout << "Exiting Program. Thank you and have a great day!" << endl;
				break;

			default:
				cout << "That is not a valid choice, please try again." << endl;
				
		}

	} while (choice != 12);
	
	return 0;
}
