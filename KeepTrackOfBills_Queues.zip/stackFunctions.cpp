// Doney Tran
// CS 163 Hybrid
// 1/30/23
// Program 2

#include "stack.h"
#include "queue.h"
// This is the implementation of the stack member functions. This stack works with
// the bill class and stores bill objects. The client will be able to push, pop, display, and
// peek at the stack.
/*
// Data structure & private data members
struct stackNode
{
	billFrame * bill;
	stackNode * next;

};

	int topIndex;
	stackNode * head;	

*/

// Initialize the stack data members to zero equivalents
stack::stack()
{
	topIndex = 0;
	head = nullptr;

}

// reset all stack data members back to zero equivalents and deallocate all
// allocated memory
stack::~stack()
{
	topIndex = 0;

	
	recursiveRemoveNode(head);	

}

// This function will retrieve a bill that is on the top of the current stack
// it will return a 1 if successful and throw a 0 if it failed
int stack::peek(billFrame & bill) const
{
	if (!head) throw 0;


	if (!topIndex && head->next)
	{
		return bill.addWholeBill(head->bill[MAX-1]);
	}
	
	if (!topIndex && !head->next)
	{
		throw 0;
	}


	return bill.addWholeBill(head->bill[topIndex-1]);

}

// This function will push a bill to a new stack or an existing stack
// it will return a 1 if successful
int stack::push(const billFrame & billToPush)
{
	stackNode * hold = nullptr;

	// If there is nothing, create a new stackNode and an array of bills, and add
	// a bill to the top
	if (!head)
	{

		topIndex = 0;
		head = new stackNode;
		head->bill = new billFrame[MAX];
		head->bill[topIndex].addWholeBill(billToPush);
		head->next = nullptr;
		++topIndex;

	}

	else
	{
		// If stack is full, make a new stack and node
		if (topIndex == MAX)
		{

			topIndex = 0;
			hold = head;
			head = new stackNode;
			head->bill = new billFrame[MAX];
			head->next = hold;
			head->bill[topIndex].addWholeBill(billToPush);
			++topIndex;

		}

		else
		{

			head->bill[topIndex].addWholeBill(billToPush);
			++topIndex;

		}
	}

	return 1;
}

// This function will decrement the topIndex and only remove the bill stack array
// if it becomes empty
// It will return a 1 if successful and throw a 0 if it failed
int stack::pop(billFrame & queueBill)
{
	stackNode * hold = nullptr;
	if (!head) throw 0;

	if (!topIndex)
	{
		queueBill.addWholeBill(head->bill[topIndex]);
		topIndex = MAX;
		if (head->bill)
		{
			delete [] head->bill;
		}

		hold = head->next;
		delete head;
		head = hold;
		--topIndex;

		if (head)
		{
			topIndex = MAX;
		}

		else
		{
			topIndex = 0;
		}

	}

	else
	{
		queueBill.addWholeBill(head->bill[topIndex-1]);
		head->bill[topIndex-1].removeBill();
		--topIndex;
	}

	return 1;

}

// This function will go through a bill stack, displaying each bill
// It will return a 1 if successful and throw a 0 if it failed
int stack::displayAll() const
{
	stackNode * current = head;
	if (!head) throw 0;
	int count = topIndex;
	while (current)
	{
		//if (count == 5)
		//{
		//	current->bill[count-1].displayBill();
		//	--count;
		//}

		while (count != 0)
		{
			

			current->bill[count-1].displayBill();
			--count;
		}

		if (count == 0)
		{
			count = 5;
		}

		current = current->next;
	}
	return 1;
}

// This is a head recursive function that will traverse through and deallocate everything
// It will return a 1 if successful and throw a 0 if it failed
int stack::recursiveRemoveNode(stackNode * &head)
{
	if (!head) return 0;

	recursiveRemoveNode(head->next);
	if (head->bill)
	{
		delete [] head->bill;
	}
	delete head;
	return 1;


}



