// Doney Tran
// CS 163 Hybrid
// 1/30/23
// Program 2


// This class manages the data pieces that make up a bill. It will simplify the
// process of adding and removing a bill object from the stack ADT.

#ifndef BILL_H
#define BILL_H
#include <iostream>
#include <cctype>
#include <cstring>
class billFrame
{
	public:
		billFrame();
		~billFrame();

		int addBill(const char name[], const float &billAmount, const char description[], const char expenseType[], const char date[]);
		int addWholeBill(const billFrame & bill);
		int displayBill();
		int getExpenseType(char name[]);	
		int removeBill();
		
	private:
		char * name;
		float billAmount;
		char * description;
		char * expenseType;
		char * date;



};
#endif
