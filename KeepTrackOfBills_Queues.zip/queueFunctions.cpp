// Doney Tran
// CS 163 Hybrid
// 2/7/23
// Program 2

#include "queue.h"
// This is the implementation of the queue member functions. The 
// client can create queues to store many bills that can vary
// in size or be organized into the client's choosing. 



// Initialize private data members to it's zero equivalent
queue::queue()
{
	rear = nullptr;
}

// Deallocate all dynamic memory and set data members back to it's zero equivalent
queue::~queue()
{

	clearQueue();	

	rear = nullptr;
}

// This function will take in a bill passed in and add it to a circular linked list
// It will return a 1 if successful
int queue::enqueue(const billFrame & billToQueue)
{
	queueNode * temp = nullptr;
	if (!rear)
	{
		rear = new queueNode;
		rear->next = rear;
		rear->bill.addWholeBill(billToQueue);
	}

	else
	{
		temp = rear->next;
		rear->next = new queueNode;
		rear = rear->next;
		rear->bill.addWholeBill(billToQueue);
		rear->next = temp;
	}

	return 1;
}

// This function will delete a queueNode if there is one in the list
// It will return a 1 if successful or throw a 0 if there isn't a node
int queue::dequeue()
{

	queueNode * temp = nullptr;

	if (!rear) throw 0;

	if (rear == rear->next)
	{
		delete rear;
		rear = nullptr;
		return 1;
	}

	temp = rear->next->next;
	delete rear->next;
	rear->next = temp;
	
	return 1;

}

// This function will check what is the first bill in the queue and return that bill back
// through the argument. It will return 1 if successful or throw a 0 if there isn't a node
int queue::peek(billFrame & foundBill) const
{
	if (!rear) throw 0;	

	return foundBill.addWholeBill(rear->next->bill);

}

// This function will display what is currently in a queue if it exists.
// It will return a 1 if successful or throw a 0 if there is nothing in the queue
// to display
int queue::displayQueue()
{
	
	if (!rear) throw 0;


	return recursiveDisplay(rear->next);


}

// This function will recursively traverse through a queue to display it's
// bills. It will return a 1 if successful 
int queue::recursiveDisplay(queueNode * rear)
{


	rear->bill.displayBill();	
	if (rear == this->rear)	
	{
		return 1;
	}

	return recursiveDisplay(rear->next);

}

// This function will delete any nodes that are currently in the queue.
// It will return a 0 if it failed or return a 1 if successful
int queue::clearQueue()
{
	queueNode * temp = nullptr;
	if (!rear) return 0;

	if (rear == rear->next)
	{
		delete rear;
		rear = nullptr;
		return 1;
	}

	temp = rear;
	rear = rear->next;
	temp->next = nullptr;


	return recursiveQueueClear(rear);
}

// This function will recursively traverse through a queue and delete and deallocate dynamic memory.
// It will return a 1 if successful
int queue::recursiveQueueClear(queueNode * &rear)
{
	if (!rear) return 0;

	recursiveQueueClear(rear->next);
	delete rear;
	return 1;
}










