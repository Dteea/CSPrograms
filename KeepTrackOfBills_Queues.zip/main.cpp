// Doney Tran
// CS 163 Hybrid
// 2/2/23
// Program 2


#include "stack.h"
#include "queue.h"
using namespace std;

const int SIZE {200};
int main()
{
	// TO WHOEVER IS GRADING THIS
	// I wrote the queue menu manager to interact with just the general queue so that you
	// can test the functionality of my queue
	// The other queues will already be sorted into its places when you pop a bill off the stack
	// and the queue display will display all of them



	billFrame bill;
	billFrame emptyBill; 
	billFrame emptyBill2;
	billFrame emptyBill3;
	
	stack stack;
	queue entertainment;
	queue food;
       	queue general;	
	queue utility;
	char name[SIZE];	
	char description[SIZE];	
	char expenseType[SIZE];	
	char date[SIZE];	
	float amount {0.0};

	// For popping bills to be put into different queues
	char temp[SIZE];

	char foodname[SIZE] = "FOOD";	
	char entertainmentname[SIZE] = "ENTERTAINMENT";	
	char utilityname[SIZE] = "UTILITY";	
	int choice {0};	
	// Menu
	do
	{
		cout << endl;
		cout << "BILL MANAGER MENU" << endl;
		cout << "-----------------" << endl;
		cout << "1. Enter a bill" << endl;
		cout << "2. Add a whole bill" << endl;
		cout << "3. Push a bill to a stack" << endl;
		cout << "4. Pop a bill out a stack" << endl;
		cout << "5. Peek a stack" << endl;
		cout << "6. Display stack" << endl;

		cout << "QUEUE MANAGER" << endl;
		cout << "--------------" << endl;
		cout << "7. Enqueue a bill" << endl;
		cout << "8. Dequeue a bill" << endl;
		cout << "9. Peek a queue" << endl;
		cout << "10. Display queue" << endl;
		cout << "11: EXIT PROGRAM" << endl;

		cout << endl;

		cout << "Please look at the menu and select a function to do: ";
		cin >> choice;
		cin.ignore(100, '\n');
		cout << endl;

		// Direct the input to call a function
		switch(choice)
		{
			case 1:

				cout << "Enter the name of the organization/company/entity: ";
				cin.get(name, SIZE, '\n');
				cin.ignore(SIZE, '\n');	

				cout << "Enter the description of the bill: ";
				cin.get(description, SIZE, '\n');
				cin.ignore(SIZE, '\n');	

				cout << "Enter the type of expense (Options are utility, food, or entertainment): ";
				cin.get(expenseType, SIZE, '\n');
				cin.ignore(SIZE, '\n');	

				cout << "Enter the date of the bill in the format MM/DD/YYYY: ";
				cin.get(date, SIZE, '\n');
				cin.ignore(SIZE, '\n');	

				cout << "Enter the bill amount: ";
				cin >> amount;
				cin.ignore(SIZE, '\n');
				try
				{
					bill.addBill(name, amount, description, expenseType, date);
					cout << "Successfully added bill" << endl;	
				}

				catch (int)
				{
					cerr << "Error. A bill could not be added." << endl;
				}
				break;

			case 2:
				try
				{
					bill.addWholeBill(bill);  
					cout << "Successfully added an entire bill" << endl;	
				}

				catch (int)
				{
					cerr << "Error. A bill could not be added." << endl;
				}
				break;

			case 3:
				try				
				{
					stack.push(bill);
					cout << "Bill added to the stack" << endl;
				}

				catch (int)
				{
					cerr << "We could not push that bill." << endl;
				}
				break;

			case 4:
				try
				{
					stack.pop(emptyBill3);

					emptyBill3.getExpenseType(temp);

					if (!strcmp(temp, entertainmentname))
					{
						entertainment.enqueue(emptyBill3);	

						cout << "The last bill added in has been moved to the entertainment queue" << endl;
					}

					else if (!strcmp(temp, foodname))
					{
						food.enqueue(emptyBill3);	


						cout << "The last bill added in has been moved to the food queue" << endl;
					}

					else if (!strcmp(temp, utilityname))
					{
						utility.enqueue(emptyBill3);

						cout << "The last bill added in has been moved to the utility queue" << endl;
					}

					else
					{
						general.enqueue(emptyBill3);

						cout << "The last bill added in has been moved to the general queue" << endl;
					}
				}

				
				catch (int)
				{
					cerr << "We could not remove that last bill added in" << endl;
				}

				break;

			case 5:
				try
				{
					stack.peek(emptyBill);

					cout << "Here is the bill on top of the current stack:" << endl;
					emptyBill.displayBill();
				}

				catch (int)
				{
					cerr << "We could not find a bill on top of the bill stack" << endl;
				}
				break;

			case 6:
				try
				{

					cout << "ALL BILLS IN STACK" << endl;
					cout << "----------" << endl;
					cout << endl;
					stack.displayAll();
				}

				catch (int)
				{
					cerr << "We could not find any bills to display" << endl;
				}
				break;

			case 7:
				try
				{
					general.enqueue(bill);
					cout << "Added a bill to the general queue" << endl;
				}

				catch (int)
				{
					cerr << "Could not add a bill to the general queue" << endl;
				}
				break;

			case 8:
				try
				{
					general.dequeue();
					cout << "Removed the first bill added to the general queue" << endl;
				}

				catch (int)
				{
					cerr << "Could not remove the first bill added to the general queue" << endl;
				}
				break;

			case 9:
				try
				{
					general.peek(emptyBill2);
					cout << "This is the first bill in the general queue that has been paid" << endl;
					emptyBill2.displayBill();
				}

				catch (int)
				{
					cerr << "Could not find the first bill in the general queue that was paid" << endl;
				}
				break;

			case 10:
					cout << "ALL BILLS IN QUEUE(S)" << endl;	
					cout << "--------------------" << endl;

					try
					{
						cout << "GENERAL QUEUE" << endl;
						cout << "---------------" << endl;
						general.displayQueue();
						cout << endl << endl;
					}
					catch (int)
					{
						cerr << "Could not find a queue to display" << endl;
					}

					try
					{
						cout << "ENTERTAINMENT QUEUE" << endl;
						cout << "---------------" << endl;
						entertainment.displayQueue();
						cout << endl << endl;
					}
					catch (int)
					{
						cerr << "Could not find an entertainment queue to display" << endl;
					}

					try
					{
						cout << "FOOD QUEUE" << endl;
						cout << "---------------" << endl;
						food.displayQueue();
						cout << endl << endl;
					}
					catch (int)
					{
						cerr << "Could not find a food queue to display" << endl;
					}
					try
					{
						cout << "UTILITY QUEUE" << endl;
						cout << "---------------" << endl;
						utility.displayQueue();
						cout << endl << endl;
					}
					catch (int)
					{
						cerr << "Could not find a utility queue to display" << endl;
					}

				break;

			case 11:
				cout << "Exiting Program" << endl;
				break;
			default:
				cout << "That is not a valid input. Please try again." << endl;

		}

	} while (choice != 11);


	return 0;
}
