// Doney Tran
// CS 163 Hybrid
// 1/30/23
// Program 2


// This class will handle the organization of bills.
// It will work alongside the bill class and the queue class
// to make a an array of bills that can be added, removed, or be looked at.

#include "bill.h"
// Temporary Max stack size
const int MAX = 5;

struct stackNode
{
	billFrame * bill;
	stackNode * next;

};

class stack
{
	public:
		stack(); 
		~stack(); 

		int peek(billFrame & bill) const;
		int push(const billFrame &);
		int pop(billFrame & queueBill);
		int displayAll() const;

	private:
		int topIndex;
		stackNode * head;	
		int recursiveRemoveNode(stackNode * &head); // Recursively destroys the linked list of the stack

};


