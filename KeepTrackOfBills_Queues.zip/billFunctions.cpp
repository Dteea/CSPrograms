// Doney Tran
// CS 163 Hybrid
// 1/30/23
// Program 2


// This is the implementation of the bill member functions. The client
// can pass in data that makes up a bill to be added to the bill object
// or the client can add a whole bill object to be added. The client is
// able to also display the data members of the bill. All returns of 1
// indicate a success and a throw 0 indicates a failure of a function

#include "bill.h"

// Initialize all data members to zero value equivalents
billFrame::billFrame()
{

	name = nullptr;
	billAmount = 0.0;
	description = nullptr;
	expenseType = nullptr;
	date = nullptr;

}

// Reset all data members back to zero vcalue equivalents
billFrame::~billFrame()
{

	if (name)
	{
		delete [] name;
	}

	if (description)
	{
		delete [] description;
	}

	if (expenseType)
	{
		delete [] expenseType;
	}
	
	if (date)
	{
		delete [] date;
	}

	name = description = expenseType = date = nullptr;
	billAmount = 0.0;

}

// This function will take in data that makes up a bill from the client, and creates a deep copy of it
// it will return a 1 indicating a success and throw 0 if it failed
int billFrame::addBill(const char nameToAdd[], const float & billAmountToAdd, const char descriptionToAdd[], const char expenseTypeToAdd[], const char dateToAdd[])
{
	if ( !nameToAdd || billAmountToAdd < 0.0 || !descriptionToAdd || !expenseTypeToAdd || !dateToAdd) throw 0;

	if (name)
	{
		delete [] name;
	}

	if (description)
	{
		delete [] description;
	}

	if (expenseType)
	{
		delete [] expenseType;
	}
	
	if (date)
	{
		delete [] date;
	}

	name = description = expenseType = date = nullptr;
	billAmount = 0.0;

	name = new char [strlen(nameToAdd) + 1];
	strcpy (name, nameToAdd);

	description = new char [strlen(descriptionToAdd) + 1];
	strcpy (description, descriptionToAdd);

	expenseType = new char [strlen(expenseTypeToAdd) + 1];
	strcpy (expenseType, expenseTypeToAdd);

	date = new char [strlen(dateToAdd) + 1];
	strcpy (date, dateToAdd);

	billAmount = billAmountToAdd;


	return 1;
}








// This function will take in a bill object from the client and creates a deep copy of the object
// It will return a 1 if successful or throw a 0 if it failed
int billFrame::addWholeBill(const billFrame & aBill)
{
	return addBill(aBill.name, aBill.billAmount, aBill.description, aBill.expenseType, aBill.date);
}

// This function will display all the data members of the bill, it will return a 1 if successful and throw a 0
// if there was nothing to display
int billFrame::displayBill()
{
	using namespace std;
	if (!name || billAmount < 0.0 || !description || !expenseType || !date) throw 0;

	cout << endl;
	cout << name << " BILL" << endl;
	cout << "-----------" << endl;
	cout << "Bill Amount: $" << billAmount  << endl;
	cout << "Description: " << description << endl;
	cout << "Expense Type: " << expenseType << endl;
	cout << "Date: " << date << endl;

	return 1;
}		

// This function will check if the dates match for a bill being passed in
// It will return a 0 if it failed or return a 1 if successful
int billFrame::getExpenseType(char foundType[])
{
	for (int i = 0; i < strlen(expenseType); ++i)
	{
		expenseType[i] = toupper(expenseType[i]);
	}	

	strcpy(foundType, expenseType);

	return 1;
}

// This function will deallocate all dynamic memory of a bill
// It will return a 1 if successful
int billFrame::removeBill()
{
	if (name)
	{
		delete [] name;
	}

	if (description)
	{
		delete [] description;
	}

	if (expenseType)
	{
		delete [] expenseType;
	}
	
	if (date)
	{
		delete [] date;
	}

	name = description = expenseType = date = nullptr;
	billAmount = 0.0;
	return 1;
}
