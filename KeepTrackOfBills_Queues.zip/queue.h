// Doney Tran
// CS 163 Hybrid
// 1/30/23
// Program 2

// This class will manage a queue which each contains a set
// amount of bills in each node. It can add at the rear (enqueue)
// and remove in the "front" (dequeue).

#include "bill.h"
// This structure will utilize a circular linked list
struct queueNode
{
	billFrame bill;
	queueNode * next;
};
class queue
{
	public:
		queue();
		~queue();

		int enqueue(const billFrame & bill);
		int dequeue();
		int peek(billFrame & bill) const;
		int displayQueue();
		int clearQueue();

	private:
		queueNode * rear;
		int recursiveQueueClear(queueNode * & rear);
		int recursiveDisplay(queueNode * rear);



};
