// Doney Tran
// CS 163 Hybrd
// 2/13/23
// Program 3


// This file is the implemenation of the member functions of the character class.
// The possibilites are endless for the client to add, remove, and display characters.

// Data members
//char * name;
//char * ability;
//char * species;
//char * description;

#include "character.h"

// default constructor
characterBase::characterBase()
{
	name = ability = species = description = nullptr;
}

// default destructor
characterBase::~characterBase()
{
	if (name)
	{
		delete [] name;
	}

	if (ability)
	{
		delete [] ability;
	}

	if (species)
	{
		delete [] species;
	}

	if (description)
	{
		delete [] description;
	}

	name = ability = species = description = nullptr;
}

// This function will take in a character name, ability, speices, and description and make a deep copy of the data
// It will throw a 0 if any of the arguments are null and return a 1 if successful
int characterBase::addCharacter(char nameToAdd[], char abilityToAdd[], char speciesToAdd[], char descriptionToAdd[])
{

	if (!nameToAdd || !abilityToAdd || !speciesToAdd || !descriptionToAdd) throw 0;

	if (name)
	{
		delete [] name;
	}

	if (ability)
	{
		delete [] ability;
	}

	if (species)
	{
		delete [] species;
	}

	if (description)
	{
		delete [] description;
	}

	name = new char[strlen(nameToAdd) + 1];
	ability = new char[strlen(abilityToAdd) + 1];
	species = new char[strlen(speciesToAdd) + 1];
	description = new char[strlen(descriptionToAdd) + 1];

	strcpy(name, nameToAdd);
	strcpy(ability, abilityToAdd);
	strcpy(species, speciesToAdd);
	strcpy(description, descriptionToAdd);
	return 1;
}

// This function takes in a characterBase object and makes a deep copy of it. It will return a 1 if successful
int characterBase::addWholeCharacter(characterBase & character)
{
	return addCharacter(character.name, character.ability, character.species, character.description);
}

// This function will display the pieces of data that makes up a character. It will throw a 0 if any of 
// the data members are null, otherwise it will return a 1 if successful
int characterBase::displayCharacter()
{
	using namespace std;

	if (!name || !ability || !species || !description) throw 0;

	cout << endl;
	cout << "CHARACTER INFO" << endl;
	cout << "==============" << endl;
	cout << "NAME: " << name << endl;
	cout << "ABILITY: " << ability << endl;
	cout << "SPECIES: " << species << endl;
	cout << "DESCRIPTION: " << description << endl;
	cout << endl;

	return 1;
}

// This function will dealloacte dynamic memory of the pieces of data that makes up a
// character. It will return a 1 if successful
int characterBase::removeCharacter()
{

	if (name)
	{
		delete [] name;
	}

	if (ability)
	{
		delete [] ability;
	}

	if (species)
	{
		delete [] species;
	}

	if (description)
	{
		delete [] description;
	}

	name = species = species = description = nullptr;    

	return 1;
}

// This function will take in a character name passed in to compare it to it's own name to see if 
// it's a match. It will throw a 0 if the name passed in is null and return a 1 if there is a match. Otherwise
// the function will return a 0
int characterBase::nameMatch(char compareName[])
{
	if (!compareName) throw 0;

	if (!strcmp(compareName, name))
	{
		return 1;	
	}

	return 0;
}


// This function will take in a character ability passed in to compare it to it's own ability to see if 
// it's a match. It will throw a 0 if the ability passed in is null and return a 1 if there is a match. Otherwise
// the function will return a 0
int characterBase::abilityMatch(char compareAbility[])
{
	if (!compareAbility) throw 0;

	if (!strcmp(compareAbility, ability))
	{
		return 1;	
	}

	return 0;
}

// This function will get an empty character array and copy over the current
// character's name into that array. It will return a 1 if successful, otherwise
// it will throw a 0
int characterBase::getName(char emptyName[])
{

	if (!name) throw 0;

	strcpy(emptyName, name);

	return 1;
}

// This function will display the character length of the characterBase object's name.
// It will throw a 0 if the object's name is null, otherwise it will return a 1 indicating
// a success
int characterBase::displayNameLength()
{
	if (!name) throw 0;

	using namespace std;

	cout << name << "| Name length of: " << strlen(name) << endl;

	return 1;	
}
