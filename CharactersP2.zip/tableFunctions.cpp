// Doney Tran
// 3/1/23
// CS 163 Hybrid
// Program 4


// This file contains the implementation of functions for
// a Binary Search Tree. For organizing the names, this Binary
// Search Tree will sort names by it's character length and can
// display it in order from least amount of characters, to the most.
// All functions in this file will use wrapper functions and recursion 
// to get the job done.

#include "table.h"

// Default constructor 
table::table()
{
	
	root = nullptr;

}

// Default destructor
table::~table()
{

	destroy(root);

}

// This is the wrapper function for the recursive sorted display function.
// If the starting point of the table is null, this function will throw an 
// error message to the client
int table::displayAllNameSorted()
{
	if (!root) throw "No table to display";

	return displayAllNameSorted(root);


}

// This is the wrapper function for the recursive ability display function.
// If the starting point of the table is null, this function will throw an
// error message to the client
int table::displayAllAbility(char name[])
{
	if (!root) throw "There is nothing to display";

	return displayAllAbility(root, name);

}

// This is the wrapper function for the recursive character remove function.
// If the starting point of the table is null, this function will throw an
// error message to the client
int table::removeCharacter(char name[])
{
	if (!root) throw "There is nothing to remove";
	
	return removeCharacter(root, name);

}


// This is the wrapper function for the recursive character retrieve function.
// If the starting point of the table is null, this function will throw an
// error message to the client
int table::retrieve(char name[], characterBase & emptyCharacter)
{
	if (!root) throw "There is nothing to retrieve";

	return retrieve(root, name, emptyCharacter);
}

// This is the wrapper function for the recursive character add function.
// If the starting point of the table is null, this function will throw an
// error message to the client
int table::add(char name[], characterBase & addCharacter)
{
	if (!name) throw "No name was passed in to add";
	return add(root, name, addCharacter);	

}

// This function will have a file name and characterBase object passed in.
// It will read in a file formated in the way: name | ability | species | description \n (also known as a new line or pressing enter)
// and work with the add function to insert a character into the table. 
// It will throw a 0 if the file name passed in is null or if the file couldn't be opened. 
// Otherwise the function will return the total of the characters that were added in
int table::loadFile(char fileName[], characterBase & fillCharacter)
{

	if (!fileName) throw 0;

	using namespace std;
	ifstream moveIn;

	char name[SIZE2];	
	char ability[SIZE2];	
	char species[SIZE2];	
	char description[SIZE2];	
	int count {0};

	moveIn.open(fileName);
	
	if (moveIn)
	{
		
		moveIn.get(name, SIZE2, '|');
		moveIn.ignore(SIZE2, '|');

		while (moveIn && !moveIn.eof())
		{

			moveIn.get(ability, SIZE2, '|');
			moveIn.ignore(SIZE2, '|');

			moveIn.get(species, SIZE2, '|');
			moveIn.ignore(SIZE2, '|');

			moveIn.get(description, SIZE2, '\n');
			moveIn.ignore(SIZE2, '\n');

			fillCharacter.addCharacter(name, ability, species, description);
			add(name, fillCharacter);

			++count;
			// Check if next thing can be read	
			moveIn.get(name, SIZE2, '|');
			moveIn.ignore(SIZE2, '|');
		}

		moveIn.close();

	}

	else
	{
		throw 0;
	}

	return count;

}
// Recursive Functions


// This function will display all names in the table in sorted order
// from the name with the shortest name to the longest name. It will return a 1
// if it could display a name
int table::displayAllNameSorted(node * root)
{
	if (!root) return 0;

	displayAllNameSorted(root->left);
	root->character.displayCharacter();
	//root->character.displayNameLength(); // Uncomment to display the name length
	displayAllNameSorted(root->right);
	
	return 1;
}

// This function will display all the characters that match the ability name passed in
// from the client. The function will also take in the starting point of the table which is the root.
// It will return a 1 if It could display a matching character ability
int table::displayAllAbility(node * root, char ability[])
{
	if (!root) return 0;

	if (root->character.abilityMatch(ability) == 1)
	{
		root->character.displayCharacter();	
	}

	displayAllAbility(root->left, ability);
	displayAllAbility(root->right, ability);

	return 1;
}

// This function will get the starting point of a table called the root and a name passed
// in by the client to be removed from the table. There are multiple special cases the the
// function will deal with to remove a character from a specific position. It will return 1
// if it successfully removed a character, otherise it will return a 0 indicating a failure or
// that the function couldn't find a match
int table::removeCharacter(node * & root, char name[])
{
	if (!root) return 0;

	if (root->character.nameMatch(name))
	{
		// Removing a leaf
		if (!root->left && !root->right)
		{
			delete root;
			root = nullptr;
			return 1;
		}

		// Removing node with only a left child
		else if (root->left && !root->right)
		{
			node * temp = root->left;
			delete root;
			root = temp;
			return 1;
		}

		// Removing node with only a right child
		else if (root->right && !root->left)
		{
			node * temp = root->right;
			delete root;
			root = temp;
			return 1;
		}

		// Removing node with 2 children 
		else
		{
			node * current = nullptr;
			// node with 2 children but node's right's left has no child 
			if (!root->right->left)
			{
				// Getting the Inorder successor
				current = root->right;
				root->character.addWholeCharacter(current->character);
				root->right = current->right;
				delete current;
				return 1;
			}

			else
			{
				current = root->right;
				node * parent = nullptr;
				while (current->left)
				{
					parent = current;
					current = current->left;	
				}

				root->character.addWholeCharacter(current->character);
				parent->left = current->right;
				delete current;
				return 1;
			}

		}

	}

	removeCharacter(root->left, name);
	removeCharacter(root->right, name);

	// Couldn't find a match
	return 0;

}

// This function will get the starting point of the table which is the root, the name of the character to retrieve
// and an empty characterBase object. If the function find a match, it will return a 1 as well as a filled characterBase
// object with the match. Otherwise, the function will return a 0 indicating a failure or it could not find a match
int table::retrieve(node * root, char name[], characterBase & toFill)
{
	if (!root) return 0;

	if (root->character.nameMatch(name) == 1)
	{
		toFill.addWholeCharacter(root->character);
		return 1;
	}

	retrieve(root->left, name, toFill);
	retrieve(root->right, name, toFill);

	return 0;
}

// This function will recursively destroy the table returning a 1 if successful.
int table::destroy(node * &root)
{
	if (!root) return 0;

	destroy(root->left);
	destroy(root->right);

	delete root;
	root = nullptr;

	return 1;
}

// This function will get the starting point of the table also known as the root in a 
// binary search tree, a name and characterBase object that comes with the name. It will
// add a new node at a leaf of the tree. It will return a 1 if successful or a 0 indicating
// a failure
int table::add(node * &root, char name[], characterBase & addCharacter)
{
	
	if (!root)
	{
		root = new node;
		root->left = root->right = nullptr;
		root->character.addWholeCharacter(addCharacter);	
		return 1;
	}

	char currentName[SIZE2];	

	//Arrange by length of name
	root->character.getName(currentName);

	if (strlen(currentName) > strlen(name))
	{
		return add(root->left, name, addCharacter);
	}

	else
	{
		return add(root->right, name, addCharacter);
	}

	return 0;	
}

