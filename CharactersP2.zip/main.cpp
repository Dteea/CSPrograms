// Doney Tran
// 3/1/23
// CS 163 Hybrid
// Program 4

#include "table.h" 
using namespace std;


int main()
{

	characterBase person;
	characterBase empty;
	characterBase empty2;
	characterBase empty3;
	table BST;
 	char name[SIZE2];
        char ability[SIZE2];
        char species[SIZE2];
        char description[SIZE2];
        char fileName[SIZE2];
        char fileName2[SIZE2] = "characters.txt"; // Opens doney's original file
        int count {0};
        int choice {0};
        int retrieveTotal {0};

	// MENU
        do
        {
                cout << "===========" << endl;
                cout << "CHARACTER MENU" << endl;
                cout << "===========" << endl;
                cout << "1. Add Character" << endl;
                cout << "2. Add a Whole Character" << endl;
                cout << "3. Display Character" << endl;
                cout << "4. Remove Character" << endl;
                cout << endl;
                cout << "===========" << endl;
                cout << "TABLE MENU" << endl;
                cout << "===========" << endl;
                cout << "5. Insert Character Into Table" << endl;
                cout << "6. Retrieve Character From Table" << endl;
                cout << "7. Remove Character from Table" << endl;
		cout << "8. Display Matching Character Ability" << endl;
                cout << "9. Display Sorted Table By Character Length" << endl;
                cout << "10. Load External Data File" << endl;
                cout << "11. Exit Program" << endl;
                cout << endl;

                cout << "Please select an option from the table: ";
                cin >> choice;
                cin.ignore(SIZE2, '\n');


		switch (choice)
		{
			case 1:
				cout << "Please enter in a name: ";
				cin.get(name, SIZE2, '\n');
				cin.ignore(SIZE2, '\n');

				cout << "Please enter in the ability of the character: ";
				cin.get(ability, SIZE2, '\n');
				cin.ignore(SIZE2, '\n');

				cout << "Please enter the species of the character: ";
				cin.get(species, SIZE2, '\n');
				cin.ignore(SIZE2, '\n');

				cout << "Please enter the description/bio of the character: ";
				cin.get(description, SIZE2, '\n');
				cin.ignore(SIZE2, '\n');

				try
				{
					person.addCharacter(name, ability, species, description);
					cout << endl << "Filled in the character" << endl;
				}

				catch (int)
				{
					cerr << "Could not add a character" << endl;
				}
				break;

			case 2:
				try
				{
					person.addWholeCharacter(person);
					cout << endl << "Filled the character with a whole character" << endl;
				}

				catch (int)
				{
					cerr << "Could not add a whole character" << endl;
				}
				break;

			case 3:
                                try
                                {
                                        person.displayCharacter();
                                }

                                catch (int)
                                {
                                        cerr << "Cound not display the character" << endl;
                                }
                                break;

                        case 4:
                                try
                                {
                                        person.removeCharacter();
                                        cout << "Cleared out the character" << endl;
                                }

                                catch (int)
                                {
                                        cerr << "Could not clear out the character" << endl;
                                }
                                break;

			case 5:
				try
				{
					BST.add(name, person); 

					cout << ">> " << name << " << has been added to the table" << endl;
				}

				catch (const char * error)
				{
					cerr << error << endl;
				}
				break;
			case 6:
				try
				{
					char name3[SIZE2];

					cout << "Please enter in the character's name: ";
					cin.get(name3, SIZE2, '\n');
					cin.ignore(SIZE2, '\n');

					BST.retrieve(name3, empty3);
					empty3.displayCharacter();
				}

				catch (const char * error)
				{
					cerr << error << endl;
				}
				break;
			case 7:
				try
				{
					char name4[SIZE2];

					cout << "Please enter in the name of the character to remove: ";
					cin.get(name4, SIZE2, '\n');
					cin.ignore(SIZE2, '\n');
					
					BST.removeCharacter(name4);
					cout << "Removed >> " << name4 << " << from the table" << endl;
				}

				catch (const char * error)
				{
					cerr << error << endl;
				}
				break;
			case 8:
				try
				{
					char ability2[SIZE2];

					cout << "Please enter in the ability of the character: ";
					cin.get(ability2, SIZE2, '\n');
					cin.ignore(SIZE2, '\n');
					
					BST.displayAllAbility(ability2);
				}

				catch (const char * error)
				{
					cerr << error << endl;
				}
				break;
			case 9:

				try
				{
					BST.displayAllNameSorted();
				}

				catch (const char * error)
				{
					cerr << error << endl;
				}
				break;

			case 10:
                                cout << "Please enter the file name to load: ";
                                cin.get(fileName, SIZE2, '\n');
                                cin.ignore(SIZE2, '\n');
                                try
                                {
                                        count = BST.loadFile(fileName, empty2);
                                        cout << count << " CHARACTERS LOADED IN" << endl;
                                }

                                catch (int)
                                {
                                        cerr << "File does not exist, try to type in exactly what the file name is" << endl;
                                }

                                break;

                        case 11:
                                cout << "Exiting Program. Thank you and have a great day!" << endl;
                                break;

                        default:
                                cout << "That is not a valid choice, please try again." << endl;
		}
	}
	while (choice != 11);







	return 0;

}
