// Doney Tran
// CS 163 Hybrd
// 2/13/23
// Program 3

// This file has functions for a character class object.
// The client is able to make any character that will have
// it's name, powers or abilities, species, and contain a
// description or biography of the character.

//#ifndef "CHARACTER_H"
//#define "CHARACTER_H"
#include <cstring>
#include <cctype>
#include <iostream>
class characterBase
{
	public:
		characterBase();
		~characterBase();

		int addCharacter(char name[], char ability[], char species[], char description[]);
		int addWholeCharacter(characterBase & character);
		int displayCharacter();
		int removeCharacter();
		int displayNameLength();

		int nameMatch(char characterName[]);
		int abilityMatch(char ability[]);
		int getName(char emptyName[]);
	private:
		char * name;
		char * ability;
		char * species;
		char * description;


};
//#endif




