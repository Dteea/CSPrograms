// Doney Tran
// 3/1/23
// CS 163 Hybrid
// Program 4


// This file contains the blueprint for a table ADT that will
// be implemented using a Binary Search Tree data structure. 
// The client is able to load in their external data files to
// be stored and they can do various things such as displaying it
// in a certain order, adding and removing, or retrieving characters

#include "character.h"
#include <fstream>
// Constant Variables
const int SIZE2 = 601;
struct node
{
	characterBase character;
	node * left;
	node * right;
};


class table
{

	public:
		table();
		~table();

		int displayAllNameSorted();
		int displayAllAbility(char name[]);

		int removeCharacter(char name[]);
		int retrieve(char name[], characterBase & emptyCharacter);
		int add(char name[], characterBase & addCharacter);

		int loadFile(char fileName[], characterBase & emptyCharacter);


	private:
		node * root;

		int displayAllNameSorted(node * root);
		int displayAllAbility(node * root, char name[]);

		int removeCharacter(node * & root, char name[]);
		int retrieve(node * root, char name[], characterBase & toFill);
		int destroy(node * & root);
		int add(node * &root, char name[], characterBase & addCharacter);





};
