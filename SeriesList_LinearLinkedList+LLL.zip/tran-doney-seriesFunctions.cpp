// Doney Tran
// CS 163 Hybrid
// 1/18/23
// Program 1


// Preprocessor
#include "series.h"
using namespace std;


// Default constructor to set each piece of data to it's zero value.
series::series()
{
	name = genre = nullptr;
	totalSeason = totalEpisode = priority = 0;
	rating = 0.0;
}

// Destructor that will deallocate the dynamic arrays and set everything else back to it's zero value.
series::~series()
{


		if (name)
		{
			delete [] name; 
		}	
	
		if (genre)
		{
			delete [] genre;
		}	

		totalSeason = totalEpisode = priority = 0;
		rating = 0.0;

}



// For this function to work, it will need a series name, a genre, a number for the seasons, a number for an episode, and 
// a number for a rating. This function will return 1 if everything was successful.
int series::addASeries(const char nameToAdd[], const char genreToAdd[], const int & seasonToAdd, const int & episodeToAdd, const float & ratingToAdd, const int & priorityToAdd)
{
	if (!nameToAdd || !genreToAdd || seasonToAdd <= 0 || episodeToAdd <= 0 || ratingToAdd <= 0 || priorityToAdd <= 0) throw 0;

	name = new char[strlen(nameToAdd) + 1];	
	strcpy(name, nameToAdd);	
	genre = new char[strlen(genreToAdd) + 1];	
	strcpy(genre, genreToAdd);

	totalSeason = seasonToAdd;
	totalEpisode = episodeToAdd;
	rating = ratingToAdd;	
	priority = priorityToAdd;
	return 1;
}


// This function takes in a whole series object to add to a series. it will return 1 if everything was successful.

int series::addWholeSeries(const series & newSeries)
{
	return addASeries(newSeries.name, newSeries.genre, newSeries.totalSeason, newSeries.totalEpisode, newSeries.rating, newSeries.priority);
}


// This function displays all the pieces that make up a series and does not need any arguments.
int series::displaySeries()
{
	cout << "Series Name: " << name << endl;
	cout << "Genre: " << genre << endl;
	cout << "Total Season(s): " << totalSeason << endl;
	cout << "Total Episode(s): " << totalEpisode << endl;
	cout << "Rating: " << rating << endl;
	cout << "Priority: " << priority << endl;
	cout << endl;
	return 1;
}

// This function is called when the sourceFunctions needs to be supplied
// the priority of a series to sort it's series list.
// It returns the priority data member to be used .
int series::getPriority()
{
	return priority;
}

int series::getGenre(const char genreToCheck[])
{
	if (!strcmp(genreToCheck, genre))
	{
		return 1;
	}
			
	else
	{
		return 0;
	}	
}



