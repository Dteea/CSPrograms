// Doney Tran
// CS 163 Hybrid
// 1/16/23
// Program 1


// Preprocessor
#include <iostream>
#include <cctype>
#include <cstring>
#include "series.h"
// This file contains the list of sources that will work with a series class other to store information about
// a client's plan to watch shows and series from their sources.


// Linear linked list that will store the name of a source and the location of a list of series 
// Some source examples are your friends or family, social media like facebook, instagram, or tiktok
struct watchSource
{
	char * sourceName;
	struct seriesNode * seriesHead;
	watchSource * next;
};

// Linear linked list that stores a list of series for a source.
struct seriesNode
{

	series aSeries;
	seriesNode * next;
};

// This class manages a list of sources from the client. You are able to add and display a list of sources. 
class sourceList 
{
	public:
		sourceList(); // default constructor
		~sourceList(); // destructor
		int addSource(const char sourceName[]);
		int addSeriesToSourceList(const char name[], const series &seriesToAdd); 
		int displayList();	
		int findAndDisplaySource(const char name[]); 
		int removeSource(const char name[]);
		int displayGenre(const char genre[]);		
	private:
		watchSource * head;
		watchSource * tail;
		int displayRecursive(watchSource * &head);

};







