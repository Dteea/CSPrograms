// Doney Tran
// CS 163 Hybrid
// 1/20/23
// Program 1

#include "sourceList.h"
using namespace std;


const int SIZE {200};

int main()
{


	sourceList newList;
	series newSeries;
	
	char sourceName[SIZE];
	char seriesName[SIZE];
	char genre[SIZE];
	int totalSeason {0};
	int totalEpisode {0};
	float rating {0.0};
	int priority {0};
	int choice {0};
	//Menu function
	do
	{
		cout << endl;
		cout << "MENU FUNCTION" << endl;
		cout << "-------------" << endl;
		cout << "1. Add a source" << endl;
		cout << "2. Add a series" << endl;
		cout << "3. Add a series to a source" << endl;
		cout << "4. Remove A source" << endl;
		cout << "5. Find and display a source " << endl;
		cout << "6. Display the source list" << endl;
		cout << "7. Find series genre" << endl;
		cout << "Select a number: ";
		cin >> choice;
		cin.ignore(100, '\n');
		cout << endl;
		switch(choice)
		{
			case 1:

				cout << "Enter the name of the Source: ";
				cin.get(sourceName, SIZE, '\n');
				cin.ignore(200, '\n');
				try
				{
					newList.addSource(sourceName);
					cout << "ADDED A NAME TO THE SOURCE LIST" << endl;
				}

				catch (int)
				{
					cerr << "could not add to the source list" << endl;
				}
				break;
			case 2:
					
				cout << "Enter the name of the series: ";
				cin.get(seriesName,SIZE,'\n');
				cin.ignore(200, '\n');

				cout << "Enter the genre of the series: ";
				cin.get(genre,SIZE,'\n');
				cin.ignore(200, '\n');

				cout << "Enter the total season(s) of the series: ";
				cin >> totalSeason;
				cin.ignore(200, '\n');

				cout << "Enter the total episode(s) of the series: ";
				cin >> totalEpisode;
				cin.ignore(200, '\n');

				cout << "Enter the rating of the series: ";
				cin >> rating;
				cin.ignore(200, '\n');

				cout << "Enter the priority of the series: ";
				cin >> priority;
				cin.ignore(200, '\n');

				try
				{
					newSeries.addASeries(seriesName, genre, totalSeason, totalEpisode, rating, priority);
					cout << "SUCCESSFULY CREATED A FILLED SERIES" << endl;
				}

				catch (int)
				{
					cerr << "Could not fill the series" << endl;
				}
				break;
			case 3:
				
				cout << "Enter the name of the Source to add a series to: ";
				cin.get(sourceName, SIZE, '\n');
				cin.ignore(200, '\n');

				try
				{
					newList.addSeriesToSourceList(sourceName, newSeries);
					cout << "SERIES ADDED TO THE SOURCE NAMED: " << sourceName << endl;
				}

				catch (int)
				{
					cerr << "Could not add series to the source" << endl;
				}
				break;
			case 4:

				cout << "Enter the name of the Source to remove: ";
				cin.get(sourceName, SIZE, '\n');
				cin.ignore(200, '\n');
				try
				{
					newList.removeSource(sourceName);
					cout << "REMOVED THE SOURCE WITH THE NAME:" << sourceName << endl;
				}

				catch (int)
				{
					cerr << "could not find the name" << endl;
				}	
				break;
			case 5:
				try
				{

					cout << "Enter the name of the Source to display: ";
					cin.get(sourceName, SIZE, '\n');
					cin.ignore(200, '\n');
					newList.findAndDisplaySource(sourceName);
					cout << endl;
					cout << "FOUND A MATCH" << endl;
				}

				catch (int)
				{
					cerr << "Could not find a matching source" << endl;
				}
				break;

			case 6:
		
				try
				{
					cout << "LIST OF SOURCES" << endl;
					newList.displayList();
				}

				catch (int)
				{
					cerr << "There is nothing in the list" << endl;
				}
				break;
			case 7:
				try
				{
					cout << "Enter the genre of a series: ";
					cin.get(genre, SIZE, '\n');
					cin.ignore(200, '\n');
					newList.displayGenre(genre);
				}

				catch (int)
				{
					cerr << "Could not find any series with the genre: " << genre << endl;
				}
				break;
			default:
				cout << "Exiting Program" << endl;
		}
	} while (choice != -1);



	return 0;
}
