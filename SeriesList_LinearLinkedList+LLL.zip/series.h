// Doney Tran
// CS 163 Hybrid
// 1/18/23
// Program 1


// Preprocessor
#include <iostream>
#include <cctype>
#include <cstring>


// This class manages the information about a series and can add, display, or
// take in a series and add it all at once. It will be working along side the sourcelist.h 
// to create an organzied collection that the client can look at
	
class series
{
	public:
		series(); // default constructor
		~series(); // destructor
		int addASeries(const char[], const char [], const int&, const int &, const float &, const int &); // Add a single series in
		int addWholeSeries(const series & seriesToAdd); // Add a whole series all at once
		int displaySeries();
		int getPriority();
		int getGenre(const char name[]);
	private:	

		char * name;
		char * genre;
		int totalSeason;
		int totalEpisode;
		float rating;
		int priority;
};

