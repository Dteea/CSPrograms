// Doney Tran
// CS 163 Hybrid
// 1/16/23
// Program 1


// Preprocessor
#include "sourceList.h"
using namespace std;
/*
struct watchSource
{
	char * sourceName;
	seriesNode * seriesHead;		
	watchSource * next;
};
*/

// default constructor to set the series head to nullptr to
// get ready to store sources.
sourceList::sourceList() 
{
	head = tail = nullptr;
}

// destructor to deallocate dynamic memory and destroy the source list
sourceList::~sourceList() 
{
	watchSource * temp = nullptr;
	seriesNode * current = nullptr;
	seriesNode * previous = nullptr;
	// Traverse through the show source list while deallocating dynamic memory and removing everything
	while (head)
	{
		temp = head;
		// Check if there is a source name 
		if (temp->sourceName)
		{
			delete [] temp->sourceName;
		}
		temp->sourceName = nullptr;
		// Check if there is data in the series list
		if (temp->seriesHead)
		{
			// Traverse through the series list to delete everything
			while (current)
			{
				previous = current;
				current = current->next;
				delete previous;
			}
			// Once everything in the series is deleted, delete the seriesHead
			delete temp->seriesHead;
		}		
		temp->seriesHead = nullptr;
		// Move the temp pointer to the next source to destroy
		temp = temp->next;
		delete head;
		head = temp;
	}

	head = tail = temp = nullptr;
	current = previous = nullptr;
}

// This function uses the name passed in to create a new source to be added to a list.
// It will return a 1 if the function was able to create a new source
int sourceList::addSource(const char name[])
{

	if (!name) throw 0;
	
	watchSource * current = head;

	// Check if there is a duplicate name being passed in
	while (current)
	{
		if(!strcmp(current->sourceName, name))
		{
			throw 0;
		}
		
		current = current->next;
	}	
	watchSource * temp = new watchSource;
		
	// Allocate an array of the right size and copy over the passed in name
	temp->sourceName = new char [strlen(name) + 1];
	strcpy(temp->sourceName, name);
	temp->next = nullptr;
	temp->seriesHead = nullptr;
	// Add a source if there is nothing in the list 	
	if (!head)
	{
		head = tail = temp;
	}

	// Add a source at the end if there is at least a source in the list
	else
	{
		tail->next = temp;
		tail = tail->next;
	}
	return 1;
}

// This function uses a source name passed in and a series object to add a series 
// to the source that recommened that. It will be sorted in the priority that the client has provided.
// The function returns 1 if it could add a series.
int sourceList::addSeriesToSourceList(const char name[], const series & seriesToAdd) 
{
	watchSource * current = head;
	int success = 0;	
	seriesNode * temp = nullptr;


	if (!name) throw 0;
	// Search through the sources to find the right name
	while (current)
	{

		// Check if the named passed in matches with a source currently stored in the list 
		if(!strcmp(current->sourceName, name))
		{

			seriesNode * seriesCurrent = nullptr;

			// If there is no series list, make a new starting point
			if(!current->seriesHead)
			{
				current->seriesHead = new seriesNode;	
				current->seriesHead->next = nullptr;
				success = current->seriesHead->aSeries.addWholeSeries(seriesToAdd);
			}

			// Traverse through to find a spot to insert the series based on priority 
			else
			{
				seriesCurrent = current->seriesHead;
		
				temp = new seriesNode;
				success = temp->aSeries.addWholeSeries(seriesToAdd);
				temp->next = nullptr;

				// Make the series head point to the series added in if it's priority is greater than what the current head series was 
				if (temp->aSeries.getPriority() < current->seriesHead->aSeries.getPriority())
				{
					temp->next = current->seriesHead;
					current->seriesHead = temp;

				}

				
				else
				{
					
					// Compare the priority to the next series in the list 	
					while (seriesCurrent->next && temp->aSeries.getPriority() > seriesCurrent->next->aSeries.getPriority())
					{
						seriesCurrent = seriesCurrent->next;
						
					}
					temp->next = seriesCurrent->next;
					seriesCurrent->next = temp;
					

				}
					
			}
	

		}

		current = current->next;
	}	

	return success;
}

// Displays what the source list currently has. The function will
// return 1 if it successfully displayed
int sourceList::displayList()	
{
	// Don't do anything if there is no list
	if (!head) throw 0;

	return displayRecursive(head);
}

// This function uses the name passed in to search the source list for a matching name.
// If the source was found, the function will display to the client the series associated
// with the source. It will return a 1 if it was successful.
int sourceList::findAndDisplaySource(const char name[]) 
{
	// Get out of function if there is no name
	if (!name) throw 0;

	watchSource * current = head;
	
	// Traverse through the sources	
	while (current)
	{
		if (!strcmp(current->sourceName, name))
		{
			cout << "FOUND A MATCH" << endl;
			
			cout << "Source Name: " << name << endl;
			cout << "------------" << endl;	
			seriesNode * temp = current->seriesHead;
			while (temp)
			{
				temp->aSeries.displaySeries();
				temp = temp->next;

			}
			
		}	

		current = current->next;
	}

	return 1;
}

// This function will use the name passed in to search through the current sources. If the function finds
// a matching source, it will remove that source. It will return a 1 if successful.
int sourceList::removeSource(const char name[])
{

	if (!name) throw 0;

	watchSource * currentSource = head;
	watchSource * previousSource = nullptr;
	seriesNode * currentSeries = nullptr;
	seriesNode * previousSeries = nullptr;

		// If there is a match and it is the only one in the source list
		if (!strcmp(currentSource->sourceName, name) && !currentSource->next)
		{
			if (currentSource->seriesHead)
			{

				currentSeries = currentSource->seriesHead;
				if (currentSource->sourceName)
				{
					delete [] currentSource->sourceName;
					currentSource->sourceName = nullptr;
				}

				while (currentSeries)
				{
					previousSeries = currentSeries;
					currentSeries = currentSeries->next;
					delete previousSeries;	
				}
				previousSeries = nullptr;

			}	
			currentSource->seriesHead = nullptr;
			delete currentSource;
			head = nullptr;

		}


		// If there is more than 1 node and the match is the seriesHead 
		else if (!strcmp(currentSource->sourceName, name) && currentSource->next)
		{

			if (currentSource->seriesHead)
			{

				currentSeries = currentSource->seriesHead;
				if (currentSource->sourceName)
				{
					delete [] currentSource->sourceName;
					currentSource->sourceName = nullptr;
				}

				while (currentSeries)
				{
					previousSeries = currentSeries;
					currentSeries = currentSeries->next;
					delete previousSeries;	
				}
				previousSeries = nullptr;

			}	
			currentSource->seriesHead = nullptr;
			head = currentSource->next;
			delete currentSource;

		}
		
		// Remove at the end of the source list if a name matched
		else if (!strcmp(currentSource->sourceName, name) && !currentSource->next)
		{
			while (currentSource)	
			{
				if (!strcmp(currentSource->sourceName, name) && !currentSource->next)
				{

					if (currentSource->seriesHead)
					{

						currentSeries = currentSource->seriesHead;
						if (currentSource->sourceName)
						{
							delete [] currentSource->sourceName;
							currentSource->sourceName = nullptr;
						}

						while (currentSeries)
						{
							previousSeries = currentSeries;
							currentSeries = currentSeries->next;
							delete previousSeries;	
						}
						previousSeries = nullptr;

					}	
					currentSource->seriesHead = nullptr;
					delete currentSource;
					previousSource->next = nullptr;
					

				}


				previousSource = currentSource;
				currentSource = currentSource->next;

			}
		}
		
		// Delete a node and link it up to another node
		else
		{
			while (currentSource)	
			{
				if (!strcmp(currentSource->sourceName, name))
				{

					if (currentSource->seriesHead)
					{

						currentSeries = currentSource->seriesHead;
						if (currentSource->sourceName)
						{
							delete [] currentSource->sourceName;
							currentSource->sourceName = nullptr;
						}

						while (currentSeries)
						{
							previousSeries = currentSeries;
							currentSeries = currentSeries->next;
							delete previousSeries;	
						}
						previousSeries = nullptr;

					}	
					currentSource->seriesHead = nullptr;
					previousSource->next = currentSource->next;
					delete currentSource;
				}


				previousSource = currentSource;
				currentSource = currentSource->next;

			}


		}	
		
	return 1;
}

int sourceList::displayGenre(const char genre[])		
{

	// Get out of function if there is list
	if (!head) throw 0;

	watchSource * current = head;
	
	// Traverse through the sources	
	while (current)
	{
			seriesNode * temp = current->seriesHead;
			while (temp)
			{
				if (temp->aSeries.getGenre(genre))
				{
					temp->aSeries.displaySeries();
				}
				temp = temp->next;

			}
			

		current = current->next;
	}



	return 1;
}

// This function will recursively traverse through a list
// and display what the source is and the series it contains
int sourceList::displayRecursive(watchSource * &head)
{

	seriesNode * temp = head->seriesHead;
	
	//Base case
	if (!head) return 1; 

	// If there is only one source	
	if(!head->next)
	{
		cout << "Source Name: " << head->sourceName << endl;
		cout << "-----------------" << endl;
		// Traverse through the series list recommended by the source	
		if (temp)
		{
			while (temp)	
			{
				temp->aSeries.displaySeries();
				temp = temp->next;
			}
		}
		return 1;
	}

	cout << "Source Name: " << head->sourceName << endl;
	cout << "-----------------" << endl;

	// Traverse through the series list recommended by the source	
	if (temp)
	{
		while (temp)	
		{
			temp->aSeries.displaySeries();
			temp = temp->next;
		}
	}
	
	return displayRecursive(head->next);

}

	

